﻿/*
C4450
Program 2
CIS 199-75
3/9/2017

This program allows you to enter a students last name in a text box, and select a students class standing via radio button.
Based on the input provided, when the submit button is clicked a message box will show the date and time registration begins for that student.

*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            string date = null; //variable for registration date
            string time = null; //variable for registration time
            string lastName = lastNameTextBox.Text; //variable for last name
            char firstLetter; //variable for first letter of last name
           

            //get first letter of last name
            firstLetter = lastName[0];

            //converts the first letter char to uppercase if it is lower case
            if (char.IsLower(firstLetter))
            {
                char.ToUpper(firstLetter);
            }


            //logic to determine registration date
            if (seniorRadioButton.Checked)
            {
                date = "March 29";
            }
            else if (juniorRadioButton.Checked)
            {
                date = "March 30";
            }
            else if (sophomoreRadioButton.Checked)
            {
                if (firstLetter <= 'B' || firstLetter >= 'T')
                {
                    date = "March 31";
                }
                else
                {
                    date = "April 3";
                }
            }
            else if (freshmanRadioButton.Checked)
            {
                if (firstLetter <= 'B' || firstLetter >= 'T')
                {
                    date = "April 4";
                }
                else
                {
                    date = "April 5";
                }
            }

            //logic to determine registration time
            if (seniorRadioButton.Checked || juniorRadioButton.Checked)
            {
                if (firstLetter >= 'P' && firstLetter <= 'S')
                {
                    time = "8:30 AM";
                }
                else if (firstLetter >= 'T')
                {
                    time = "10:00 AM";
                }
                else if (firstLetter >= 'A' && firstLetter <= 'D')
                {
                    time = "11:30 AM";
                }
                else if (firstLetter >= 'E' && firstLetter <= 'I')
                {
                    time = "2:00 PM";
                }
                else
                {
                    time = "4:00 PM";
                }   
            }
            else if (sophomoreRadioButton.Checked || freshmanRadioButton.Checked)
            {
                if ((firstLetter >= 'P' && firstLetter <= 'Q') || (firstLetter >= 'C' && firstLetter <= 'D'))
                {
                    time = "8:30 AM";
                }
                else if ((firstLetter >= 'R' && firstLetter <= 'S') || (firstLetter >= 'E' && firstLetter <= 'F'))
                {
                    time = "10:00 AM";
                }
                else if ((firstLetter >= 'T' && firstLetter <= 'V') || (firstLetter >= 'G' && firstLetter <= 'I'))
                {
                    time = "11:30 AM";
                }
                else if ((firstLetter > 'W') || (firstLetter >= 'J' && firstLetter <= 'L')) 
                {
                    time = "2:00 PM";
                }
                else
                {
                    time = "4:00 PM";
                }
            }

            //displays the date and time registration begins in a message box
            MessageBox.Show("Registration begins on " + date + " at " + time);
        }
    }
}
