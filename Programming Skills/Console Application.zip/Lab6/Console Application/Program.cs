﻿/*
C4450
Lab 6
CIS-199-75
3/12/2017

This program creates patterns of triangles in a console
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MAX_ROWS = 10;

            Console.Write("Pattern A");
            Console.WriteLine();
            Console.WriteLine();

            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int star = 1; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }

            Console.WriteLine();
            Console.Write("Pattern B");
            Console.WriteLine();
            Console.WriteLine();
            
            for (int row = 10; row <= MAX_ROWS && row > 0; row--)
            {
                for (int star = 1; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }

            Console.WriteLine();
            Console.Write("Pattern C");
            Console.WriteLine();
            Console.WriteLine();

            for (int row = 10; row <= MAX_ROWS && row > 0; row--)
            {
                for (int space = 0; space <= MAX_ROWS - row; space++)
                    Console.Write(" ");
                for (int star = 1; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }

            Console.WriteLine();
            Console.Write("Pattern D");
            Console.WriteLine();
            Console.WriteLine();

            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int space = 1; space <= (MAX_ROWS - row); space++)
                    Console.Write(" ");
                for (int star = 1; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }
        }
    }
}
